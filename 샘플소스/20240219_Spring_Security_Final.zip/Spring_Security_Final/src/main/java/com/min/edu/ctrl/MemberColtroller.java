package com.min.edu.ctrl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.min.edu.service.UserInfoServiceImpl;
import com.min.edu.vo.UserInfoVo;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class MemberColtroller {

	@Autowired
	private UserInfoServiceImpl service;

	@Autowired
	private PasswordEncoder passwordEncoder;


	//회원가입 폼 이동
	@GetMapping("/joinForm.do")
	public String joinForm() {
		log.info("CommonColtroller joinForm.do");

		return "joinForm";
	}

	//회원가입 처리
	@PostMapping("/join.do")
	public String join(UserInfoVo vo) throws UnsupportedEncodingException {
		log.info("CommonColtroller 회원가입 정보 : {}", vo);

		// 비밀번호 BCryptPasswordEncoding 처리
		String encodePassword = passwordEncoder.encode(vo.getPassword());
		vo.setPassword(encodePassword);

		int n = service.insertUserInfo(vo);
		log.info("CommonColtroller 회원가입 처리 수 : {}", n);

		return "redirect:./index.jsp";
	}

	//회원가입 처리(자동생성용)
	@GetMapping("/autoJoin.do")
	public void autoJoin(HttpServletResponse response) throws IOException {
		log.info("CommonColtroller 자동 회원가입 처리");
		
		String id = "test";
		String name = "테스트";
		String pw = "1111";
		
		UserInfoVo vo = new UserInfoVo();
		int n = 0;
		for(int i=1;i<=10;i++) {
			log.info("i : {}", i);
			// 비밀번호 BCryptPasswordEncoding 처리
			String encodePassword = passwordEncoder.encode(pw);
			vo.setId(id+""+i);
			vo.setName(name+""+i);
			vo.setPassword(encodePassword);
			if(i>=10) {
				vo.setAuth("ROLE_SYSADMIN");
			}else if (i>=7) {
				vo.setAuth("ROLE_ADMIN");
			}else {
				vo.setAuth("ROLE_USER");
			}
			StringBuffer sb = new StringBuffer();
			sb.append("<script>");
			try {
				n =+ service.insertAutoUserInfo(vo);
				log.info("CommonColtroller 자동 회원가입 처리 수 : {}", n);
				sb.append("alert('자동생성이 완료 되었습니다.');");
			}catch(Exception ex) {
				ex.printStackTrace();
				sb.append("alert('오류가 발생하였습니다.');");
			}
			sb.append("location.href='./index.jsp';");
			sb.append("</script>");
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print(sb);

		}
	}

	@GetMapping("/getUserInfoAllList.do")
	public String getUserInfoAllList(Model model) {
		log.info("CommonColtroller 멤버 전체 리스트");
		
		List<UserInfoVo> lists = service.getUserInfoAllList();
		log.info("CommonColtroller 멤버 전체 리스트 조회 : {}", lists);
		
		model.addAttribute("lists", lists);
		return "getUserInfoAllList";
	}

	//로그인 폼 이동
	@GetMapping("/loginForm.do")
	public String loginForm(String error, String logout, Model model) {
		log.info("error : {}", error);
		log.info("logout : {}", logout);

		if (error != null) {
			model.addAttribute("error", "로그인 오류! 계정을 확인하세요.");
		}

		if (logout != null) {
			model.addAttribute("logout", "로그아웃!!");
		}

		return "loginForm";
	}
	
	
}
