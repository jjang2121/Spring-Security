package com.min.edu.ctrl;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class SampleController {
	
	@GetMapping("/all.do")
	public String doAll() {
		log.info("SampleController All 모두접근 가능");
		return "all";
	}
	
	//회원권한 페이지 접근
	@GetMapping("/member.do")
	public String doMember() {
		log.info("SampleController Member 로그인 회원만 접근 가능");
		return "member";
	}
	
	//관리자 권한 페이지 접근
	@GetMapping("/admin.do")
	public String doAdmin() {
		log.info("SampleController Admin만 접근 가능");
		return "admin";
	}
	@GetMapping("/adminManager1.do")
	public String doAdminManager1() {
		log.info("SampleController Admin만 접근 가능_Manager1");
		return "adminManager1";
	}
	@GetMapping("/adminManager2.do")
	public String doAdminManager2() {
		log.info("SampleController Admin만 접근 가능_Manager2");
		return "adminManager2";
	}

	//시스템관리자 권한 페이지 접근
	@GetMapping("/system.do")
	public String doSystem() {
		log.info("SampleController System Admin만 접근 가능");
		return "system";
	}
}
