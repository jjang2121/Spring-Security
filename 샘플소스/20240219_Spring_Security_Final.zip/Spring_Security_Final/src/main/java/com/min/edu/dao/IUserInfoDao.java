package com.min.edu.dao;

import java.util.List;

import com.min.edu.vo.UserInfoVo;

public interface IUserInfoDao {
	public UserInfoVo getUserInfo(String id);

	public int insertUserInfo(UserInfoVo vo);

	public int insertAutoUserInfo(UserInfoVo vo);

	public List<UserInfoVo> getUserInfoAllList();
}
