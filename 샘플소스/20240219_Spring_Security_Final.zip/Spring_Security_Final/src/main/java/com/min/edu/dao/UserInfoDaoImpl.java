package com.min.edu.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.min.edu.vo.UserInfoVo;

@Repository
public class UserInfoDaoImpl implements IUserInfoDao {

	@Autowired
	private SqlSessionTemplate sessionTemplate;
	private final String NS = "com.min.edu.dao.UserInfoDaoImpl.";
	
	
	@Override
	public UserInfoVo getUserInfo(String id) {
		return sessionTemplate.selectOne(NS+"getUserInfo", id);
	}


	@Override
	public int insertUserInfo(UserInfoVo vo) {
		return sessionTemplate.insert(NS+"insertUserInfo", vo);
	}

	@Override
	public int insertAutoUserInfo(UserInfoVo vo) {
		return sessionTemplate.insert(NS+"insertAutoUserInfo", vo);
	}


	@Override
	public List<UserInfoVo> getUserInfoAllList() {
		return sessionTemplate.selectList(NS+"getUserInfoAllList");
	}

}
