package com.min.edu.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.min.edu.dao.IUserInfoDao;
import com.min.edu.vo.UserInfoVo;

import lombok.extern.slf4j.Slf4j;

/*
UserDetailsService를 구현한 LoginService 클래스. 
사용자가 입력한 사용자 아이디를 기반으로 사용자 정보를 데이터베이스에서 검색하고, 해당 사용자의 권한 정보를 로드하여 UserDetails 객체로 반환처리.
*/
@Slf4j
public class LoginService implements UserDetailsService {
	
	@Autowired
	private IUserInfoDao dao;

	/*
	loadUserByUsername(String userId)은 UserDetailsService 인터페이스의 추상메서드로 사용자의 아이디를 입력받아 사용자의 상세정보를 로드
	*/
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		log.info("LoginService loadUserByUsername : {}", userId);
		log.info("LoginService repository : {}", dao);

		UserInfoVo userInfoVo = dao.getUserInfo(userId);	//userId로 상세정보 조회
		log.info("LoginService userInfoVo : {}", userInfoVo);
		
		if(userInfoVo != null) {	//정보가 있다면...
			/*
			ROLE 정보가 여러개 있다면 Collection 객제로 전달한다.
			Collection<SimpleGrantedAuthority> roles = new ArrayList<SimpleGrantedAuthority>();
			roles.add(new SimpleGrantedAuthority(userInfoVo.getAuth()));
			return new User(userId, userInfoVo.getPassword(), roles);
			*/
			return new User(userId, userInfoVo.getPassword(), AuthorityUtils.createAuthorityList(userInfoVo.getAuth()));
		}else {
			return null;
		}

	}
}
