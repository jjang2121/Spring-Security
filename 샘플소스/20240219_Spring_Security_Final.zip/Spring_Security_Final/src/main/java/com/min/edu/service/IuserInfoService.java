package com.min.edu.service;

import java.util.List;

import com.min.edu.vo.UserInfoVo;

public interface IuserInfoService {
	public UserInfoVo getUserInfo(String id);

	public int insertUserInfo(UserInfoVo vo);

	public int insertAutoUserInfo(UserInfoVo vo);
	
	public List<UserInfoVo> getUserInfoAllList();
}
