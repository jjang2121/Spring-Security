package com.min.edu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.min.edu.dao.IUserInfoDao;
import com.min.edu.vo.UserInfoVo;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserInfoServiceImpl implements IuserInfoService {

	@Autowired
	private IUserInfoDao dao;
	
	@Override
	public UserInfoVo getUserInfo(String id) {
		log.info("UserInfoServiceImpl getUserInfo");
		
		return dao.getUserInfo(id);
	}

	@Override
	public int insertUserInfo(UserInfoVo vo) {
		return dao.insertUserInfo(vo);
	}
	
	@Override
	public int insertAutoUserInfo(UserInfoVo vo) {
		return dao.insertAutoUserInfo(vo);
	}

	@Override
	public List<UserInfoVo> getUserInfoAllList() {
		return dao.getUserInfoAllList();
	}
	

}
